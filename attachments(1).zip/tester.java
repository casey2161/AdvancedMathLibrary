package com.AdvancedMath;

import java.util.ArrayList;

public class tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Function f = new Function("3*x","x");
		double y = f.solve(3);
		
	}
}
